function load() 
{
    amount();
}
function numvalidate(qty)
{ 
   if(IsNumeric(qty))
   {
     //alert("ok");
     if(qty == 0)
     {
       Alert.render("please give an quantity","error");  
     }
   }
   else
   {
     Alert.render("please enter an value in number","error");
   } 
}
function logincheck()
{
    var usersess="";
    $.ajax({type: "POST", url: "chkusersess.php", dataType: "html",async: false,success: 
       function (result, sv) 
             {
                 usersess = result;
                 if(usersess != "false")
                 {
                   window.location.reload();
                 }
             }, 
             statusCode:
              {
                  404: function () 
                   {
                       alert("Sorry, Could not send Now,Try Again Later");
                   }
              }, error: (function ()
                {
                  alert("Sorry, Could not send Now,Try Again Later"); 
                })
            });
}
function logincheck2()
{
    var usersess="";
    $.ajax({type: "POST", url: "chkusersess.php", dataType: "html",async: false,success: 
       function (result, sv) 
             {
                 usersess = result;
                 if(usersess == "false")
                 {
                   window.location.reload();
                 }
               
             }, 
             statusCode:
              {
                  404: function () 
                   {
                       alert("Sorry, Could not send Now,Try Again Later");
                   }
              }, error: (function () {
                       alert("Sorry, Could not send Now,Try Again Later");
                      })
            });
}
function IsNumeric(sText) 
{
        var ValidChars = "0123456789";
        var IsNumber = true;
        var Char;
        for (i = 0; i < sText.length && IsNumber == true; i++)
         {
            Char = sText.charAt(i);
            if (ValidChars.indexOf(Char) == -1) 
            {
                IsNumber = false;
            }
         }
        return IsNumber;
}
function IsChar(sText) 
{
        var ValidChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ";
        var IsCHAR = true;
        var Char;
        for (i = 0; i < sText.length && IsCHAR == true; i++)
         {
            Char = sText.charAt(i);
            if (ValidChars.indexOf(Char) == -1) 
            {
                IsCHAR = false;
            }
         }
        return IsCHAR;
}

function mobileinsert()
{ 
    
    
                  
}

function newsletter()
{ 
    
             	var form = $('#newletterform');
                                form.submit(function(event){
                                event.preventDefault();
                                $.ajax({
                        			type: 'POST',
                        			url: 'newsletterupdate.php',
                                    data: $('#newletterform').serialize()
                                    }).done(function(data){
                                        if(data.message=="userexists")
                                        {
                                            document.getElementById('newssuccessmsg').style.display="none";
                                            document.getElementById('newserrormsg').style.display="block";
                                            document.getElementById('newserrormsg').innerHTML="sorry,this e-mail address exists";
                                            setTimeout(function()
                                            {
                                                document.getElementById('newssuccessmsg').style.display="none";
                                             },2000);
                                        }
                                        else if(data.message=="success")
                                        {
                                            document.getElementById('newserrormsg').style.display="none";
                                            document.getElementById('newssuccessmsg').style.display="block";
                                            document.getElementById('newssuccessmsg').innerHTML="you have subscribed successfully..";
                                            
                                        }
                                        else
                                        {
                                            document.getElementById('newssuccessmsg').style.display="none";
                                            document.getElementById('newserrormsg').style.display="block";
                                            document.getElementById('newserrormsg').innerHTML = "your subscription failed";
                                        }
                                       // window.location.reload();
                        		});
                                beforesend(function()
                                {
                                    //Alert.render("loading....");
                                });
                        	});
                  
}
function updateaccount()
{ 
             	var form = $('#upadateaccform');
                            form.submit(function(event){
                        		event.preventDefault();
                        		var form_status = $('<div class="form_status"></div>');
                                	$.ajax({
                        			type: 'POST',
                        			url: 'updateaccount.php',
                                    data: $('#upadateaccform').serialize()
                                    }).done(function(data){
                                      //  alert(data.message);
                                        if(data.message=="success")
                                        {
                                            document.getElementById('myaccounterrormsg').style.display="none";
                                            document.getElementById('myaccountsuccessmsg').style.display="block";
                                            document.getElementById('myaccountsuccessmsg').innerHTML="Your chaneges have been saved successfully";
                                            setTimeout(function(){
                                                document.getElementById('myaccountsuccessmsg').style.display="none";
                                             },2000);
                                        }
                                        else
                                        {
                                            document.getElementById('myaccountsuccessmsg').style.display="none";
                                            document.getElementById('myaccounterrormsg').style.display="block";
                                            document.getElementById('myaccounterrormsg').innerHTML="Your chaneges not saved";
                                        }
                                       // window.location.reload();
                        		});
                                beforesend(function()
                                {
                                    //Alert.render("loading....");
                                });
                        	});
                  
}
function changeaccount()
{ 
    var passwordold     = document.getElementById("oldpassword").value;
    var passwordnew     = document.getElementById("newpassword").value;
    var passwordretype  = document.getElementById("retype").value;
    var s="";
    var check="";
    if(passwordold=="")
     {
       s+="please enter your old password<br />";
     }  
     else
     {
          var promises = chkpassword(passwordold);
          promises.success(function(result,sv) 
          {
               check = result;
              
          });
          if(check!="success")
          {
            s+="email or password combination is wrong<br />";
          }                
     }
     if(passwordnew=="")
     {
       s+="please enter your new password<br />";
     }
     else
     {
        if(passwordnew.length>=6)
        {
            if(passwordnew!=passwordretype)
            {
                s+="Password does not matches<br />";
            }
        }
        else
        {
             s+="Password should be minimum 6 characters long<br />";
        }
     }
     if(s!="") 
     {
         changefailure();
         document.getElementById('myaccountsuccessmsg').style.display="none";
         document.getElementById('myaccounterrormsg').style.display="block";
         document.getElementById('myaccounterrormsg').innerHTML=s;
     }
     else
     {
        changesuccess(s);
     }
}
function changesuccess(s)
{
               
             	var form = $('#changeaccform');
                            form.submit(function(event)
                            {
                        		event.preventDefault();
                        		var form_status = $('<div class="form_status"></div>');
                                	$.ajax({
                        			type: 'POST',
                        			url: 'changemypassword.php',
                                    cache:false,
                                    data: $('#changeaccform').serialize()
                                    }).done(function(data){
                                        if(data.message=="success")
                                        {
                                            document.getElementById('myaccounterrormsg').style.display="none";
                                            document.getElementById('myaccountsuccessmsg').style.display="block";
                                            document.getElementById('myaccountsuccessmsg').innerHTML="Your chaneges have been saved successfully";
                                             setTimeout(function(){window.location.reload()},2000);
                                        }
                                        else
                                        {
                                            document.getElementById('myaccountsuccessmsg').style.display="none";
                                            document.getElementById('myaccounterrormsg').style.display="block";
                                            document.getElementById('myaccounterrormsg').innerHTML="Your chaneges not saved";
                                        }  
                        		});
                                beforesend(function()
                                {
                                    //Alert.render("loading....");
                                });
             	});
                  
}
function changefailure()
{
    var form = $('#changeaccform');
    form.submit(function(event)
    {
   	    event.preventDefault();
    });
}

function changeaddress()
{ 
     var pincode  = document.getElementById("pincode").value;
     var s="";
     var check="";
     if(IsNumeric(pincode))
     {
         if(pincode.length!=6)
         {
           s+="please enter an valid pincode<br />";
         }   
     }
     else
     {
          s+="please enter an valid pincode<br />";            
     }
     if(s!="") 
     {
         changeaddressfailure();
         document.getElementById('myaccountsuccessmsg').style.display="none";
         document.getElementById('myaccounterrormsg').style.display="block";
         document.getElementById('myaccounterrormsg').innerHTML=s;
     }
     else
     {
        changeaddresssuccess();
     }
}
function changeaddresssuccess()
{
              jQuery(function($) 
                   {
                           var form = $('#changeaddressform');
                            form.submit(function(event){
                        		event.preventDefault();
                        		var form_status = $('<div class="form_status"></div>');
                                	$.ajax({
                        			type: 'POST',
                        			url: 'addressaccount.php',
                                    cache:false,
                                    data: $('#changeaddressform').serialize()
                                     }).done(function(data){
                                        if(data.message=="success")
                                        {
                                            document.getElementById('myaccounterrormsg').style.display="none";
                                            document.getElementById('myaccountsuccessmsg').style.display="block";
                                            document.getElementById('myaccountsuccessmsg').innerHTML="Your chaneges have been saved successfully";
                                             setTimeout(function(){
                                                document.getElementById('myaccountsuccessmsg').style.display="none";
                                             },2000);
                                        }
                                        else
                                        {
                                            document.getElementById('myaccountsuccessmsg').style.display="none";
                                            document.getElementById('myaccounterrormsg').style.display="block";
                                            document.getElementById('myaccounterrormsg').innerHTML="Your chaneges not saved";
                                        }  
                        		});
                                beforesend(function()
                                {
                                    //Alert.render("loading....");
                                });
                        	});
                  
                         });
}
function changeaddressfailure()
{
    var form = $('#changeaddressform');
    form.submit(function(event)
    {
   	    event.preventDefault();
    });
}
              function removeproduct(procode) 
                {
                    //confirm("hi");
                    var xmlhttp = new XMLHttpRequest();
                    if(procode != null)
                      {
                        
                        xmlhttp.onreadystatechange = function()
                         {
                             if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
                             {
                                document.getElementById('dialogbox').style.display = "none";
                                document.getElementById('dialogoverlay').style.display = "none";
                                 if (xmlhttp.responseText != "no suggestion")
                                 {
                                     
                                        amount();
                                        show(); 
                                       
                                 }
                                
                             }
                             else if(xmlhttp.readyState < 4)
                             {
                                 document.getElementById('srcart').innerHTML="<tr><td>loading...</td></tr>";
                             }
                         }
                         xmlhttp.open("GET", "removeproduct.php?prcode="+procode, true);
                         xmlhttp.send();
                      }  
                }
                function amount()
                {
                    //alert("hi");
                    var xmlhttp = new XMLHttpRequest();
                     
                     xmlhttp.onreadystatechange = function()
                         {
                             if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
                             {
                                 if (xmlhttp.responseText != "no suggestion")
                                 {
                                      document.getElementById('srcounts').innerHTML = xmlhttp.responseText.trim();
                                      document.getElementById('srcountsmobile').innerHTML = xmlhttp.responseText.trim();
                                       
                                 }
                                // alert(""+xmlhttp.responseText+ "is added");
                             }
                         }
                         xmlhttp.open("GET", "amount.php", true);
                         xmlhttp.send();
                }
                function show()
                {
                        //alert("show");
                         var xmlhttp = new XMLHttpRequest();
                         xmlhttp.onreadystatechange = function()
                         {
                             if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
                             {
                                 if (xmlhttp.responseText != "no suggestion")
                                 {
                                   document.getElementById('srcart').innerHTML = xmlhttp.responseText;
                                 }
                                // alert(""+xmlhttp.responseText+ " is added <br /> successfully");
                             }
                            else if(xmlhttp.readyState < 4)
                             {
                                  document.getElementById('srcart').innerHTML='<div class="qc-row qc-row-heading"> <span class="qc-col-qty"></span> <span class="qc-col-name"></span> <span class="qc-col-price"></span></div><div class="qc-row qc-row-item"><span class="qc-col-name"><b>loading...</b></span></div>';
                             }
                         }
                         xmlhttp.open("GET", "productshow.php", true);
                         xmlhttp.send();
                }
               
                function checkEmail(s) 
                {
                    var email = s;
                    var filter = /\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/;
            
                    if (!filter.test(s)) {
                        return false;
            
                    }
                    else {
                        return true;
            
                    }
                }
                  $(document).ready(function(){
                      var widthsauto = $(window).width();
                        //alert("hi"+widths);
                       if(widthsauto >= 786)
                       { 
                          document.getElementById("results").style.position="relative";
                          document.getElementById("results").style.marginLeft="none";
                          document.getElementById("results").style.marginRight="1.6%";
                     
                       }
                       else
                       {
                          document.getElementById("results").style.position="absolute";
                          document.getElementById("results").style.marginRight="none";
                          document.getElementById("results").style.marginLeft="2.6%";
                          
                       }
                    
                    $("#name").autocomplete({
                        source:'getautocomplete.php',
                        minLength:1,
                         appendTo: "#results",
						select: function(event, ui) 
                        {
					 		var url = 'searchresults.php?name=';
                     if(url != '#') {
					   $(window).unbind('beforeunload');
				                   location.href =  url+ui.item.value;
                              }
						}
                    });
                      $("#city").autocomplete({
                        source:'getcity.php',
                        minLength:1
                        });
                      /*$("#state").autocomplete({
                        source:'getstate.php',
                        minLength:1
                          });*/
                          
                          $("#customerdetails").click(function()
                          {
            
                                    var customername     = document.getElementById("customername").value;
                                    var customermobile   = document.getElementById("customermobile").value;
                                    var s="";
                                    if(customername !="")
                                    {
                                        s+="";
                                    }
                                    else
                                    {
                                        s+="Please enter your name<br />";
                                    }
                                    if(customermobile.length==10 && IsNumeric(customermobile))
                                    {
                                        s+="";
                                    }
                                    else
                                    {
                                        s+="Please enter valid moblie number";
                                    }
                                    
                                    if(s!="")
                                    {
                                        document.getElementById('mobileerrormsg').style.display="block";
                                        document.getElementById('mobileerrormsg').innerHTML=s;
                                    }
                                    else
                                    {
                                              $.ajax({type: "POST", url: "mobilename.php", dataType: "html", data: "customermobile=" +customermobile+"&customername="+customername,async: false,success: 
                                                function (result, sv) 
                                                {
                                                    
                                                  if(result.trim()=="Success")
                                                  {
                                                    window.location.reload();
                                                  }
                                                }, 
                                                statusCode:
                                                {
                                                    404: function () 
                                                    {
                                                         alert("Sorry, Could not send Now,Try Again Later");
                                                    }
                                                }, error: (function () {
                                                    alert("Sorry, Could not send Now,Try Again Later");
                                                })
                                              });
                                                            
                                                        
                                       
                                    }
                              });
           
                    });
              function successpost()//registeration
                   {
                      var chk="";
                      var password = document.getElementById("regpassword").value;
                      var confirmpassword = document.getElementById("regrepassword").value;
                      var email = document.getElementById("regname").value;
                      var s="";
                      if(email =="")
                          {
                            s+="please enter your email id<br />";
                          }
                      else
                      {
                        if(checkEmail(email))
                        {
                           var promise = emailexist(email);
                           promise.success(function(result,sv) 
                           {
                              chk = result;
                              
                            });
                            
                           // alert(""+chk);
                            var res="";
                             if(chk !="email available")
                             {
								 //alert(""+chk);
                               s+="SORRY!this email address already existss!<br />";
                             }
                             else if(chk !="already exists")
                             {
                                s+="";
                             }
                             else
                             {
                                s+="sorry could not register<br />";
                             }
                            
                        }
                        else
                        {
                            s+="please enter an vaild email address<br />";
                        }
                      }
                      if(password != "")
                      {
                            if(password.length>6)
                            {
                                  if(password != confirmpassword)
                                  {
                                    s+="sorry passwords does not matches";
                                  }
                                  
                            }
                            else
                            {
                                 s+="please enter password greater than 6 characters";
                            }
                          
                      }
                      else
                      {
                           s+="please enter your password";
                      }
                  
                      if(s != "")
                      {
                        failurepost();
                        var error = document.getElementById('errormsg');
                        error.style.display = "block"; 
                        error.innerHTML = s;
                      }
                      else
                      { 
                        var errorr = document.getElementById('errormsg');
                        errorr.style.display = "none"; 
                        successpost2(); 
                      }
                    
                  }
                  function emailexist(emaill)
                   {
                        var emailresult="";
                        return $.ajax({type: "POST", url: "chkemail.php", dataType: "html", data: "email=" + emaill,async: false,success: 
                            function (result, sv) 
                            {
                              emailresult = result;
                            }, 
                            statusCode:
                            {
                                404: function () 
                                {
                                     alert("Sorry, Could not send Now,Try Again Later");
                                }
                            }, error: (function () {
                                alert("Sorry, Could not send Now,Try Again Later");
                            })
                        });
                            
                   }  
                  function pindooravail(pinno)
                  {
                        var emailresult="";
                        return $.ajax({type: "POST", url: "chkdooravailcity.php", dataType: "html", data: "pinno=" + pinno,async: false,success: 
                            function (result, sv) 
                            {
                              pinnoresult = result;
                            }, 
                            statusCode:
                            {
                                404: function () 
                                {
                                     alert("Sorry, Could not send Now,Try Again Later");
                                }
                            }, error: (function () {
                                alert("Sorry, Could not send Now,Try Again Later");
                            })
                        });
                            
                 }
                  function chkpassword(pwd)
                  {
                        var passwd="";
                        return $.ajax({type: "POST", url: "chkpwd.php", dataType: "html", data: "pwd=" + pwd,async: false,success: 
                            function (result, sv) 
                            {
                              passwd = result;
                            }, 
                            statusCode:
                            {
                                404: function () 
                                {
                                     alert("Sorry, Could not send Now,Try Again Later");
                                }
                            }, error: (function () {
                                alert("Sorry, Could not send Now,Try Again Later");
                            })
                        });
                            
                 }  
               function successpost2()
               {
                   jQuery(function($) 
                   {
                        	var form = $('#registerform');
                        	form.submit(function(event){
                        		event.preventDefault();
                        		var form_status = $('<div class="form_status"></div>');
                                	$.ajax({
                        			type: 'post',
                        			url: $(this).attr('action'),
                                    data: $('form').serialize()
                                    }).done(function(data){
                                        if(data.message == "Registered successfully")
                                        {
                                            //alert(data.message);
                                             window.location.reload();
                                        }
                                       // alert("success"+data.message+"","success");
                                       
                        		});
                        	});
                   });
               }
               function failurepost()
               {
                    jQuery(function($) 
                        {
                        	var form = $('#registerform');
                        	form.submit(function(event)
                            {
                                event.preventDefault();
                               
                            });
                        });
               }
                 function cssclassone()
                    { 
                        logincheck();
                         $(function() {
                              $( "#register" ).removeClass( "active"  );
                              $( "#login" ).addClass( "active"  );
                              $( "#specification" ).removeClass( "tab-pane active " );
                              $( "#description" ).addClass( "tab-pane active "  );
                              $( "#specification").addClass( "tab-pane "  );
                          });
                    }
                    
                    function cssclasstwo()
                    { 
                         logincheck();
                        $(function() {
                              $( "#login" ).removeClass( "active"  );
                              $( "#register" ).addClass( "active"  ); 
                              $( "#description" ).removeClass( "tab-pane active "  );
                              $( "#description" ).addClass( "tab-pane "  );
                              $( "#specification" ).addClass( "tab-pane active " );
                          });
                    }
                    function loginnow()
                    {
                        var username = document.getElementById("username").value;
                        var pword = document.getElementById("pword").value;
                        var s="";
                        if(username=="")
                        { 
                          s+="please enter your username(email)<br />";
                        }
                        else
                        {
                             if(!checkEmail(username))
                             {
                                s+="please  enter valid username(email) <br />";
                             }
                        }
                        if(pword=="")
                        {
                            s+="please enter your password";
                        }
                        if(s!="")
                        {
                            faliurelogin();
                            var errorl = document.getElementById('loginerrormsg');
                            errorl.style.display = "block"; 
                            errorl.innerHTML = s;
                        }
                        else
                        {
                            successlogin();
                            var errorlr = document.getElementById('errormsg');
                            errorr.style.display = "none"; 
                        }
                    }
                 function successlogin()
                  {
                           jQuery(function($) 
                           {
                                	var form = $('#loginform1');
                                	form.submit(function(event){
                                		event.preventDefault();
                                		var form_status = $('<div class="span3"></div>');
                                        	$.ajax({
                                			type: 'post',
                                			url: $(this).attr('action'),
                                            data: $('form').serialize()
                                            }).done(function(data){
                                                if(data.message == "login success")
                                                {
                                                  window.location.reload();
                                                }
                                                else if(data.message == "login failed")
                                                {
                                                     var errorlmsg = document.getElementById('loginerrormsg');
                                                     errorlmsg.style.display = "block"; 
                                                     errorlmsg.innerHTML = "please check your user name or password";
                                                 
                                                }
                                                else
                                                {
                                                    alert(""+data.message);
                                                   var errorslmsg = document.getElementById('loginerrormsg');
                                                   errorslmsg.style.display = "block"; 
                                                   errorslmsg.innerHTML = "please check your user name or password";
                                                }
                                		});
                                	});
                           });
               }
                function faliurelogin()
                {
                              jQuery(function($) 
                                        {
                                        	var form = $('#loginform1');
                                        	form.submit(function(event)
                                            {
                                                event.preventDefault();
                                               
                                            });
                                        });
                }
            
                $(document).ready(function(){
                   
                  $("#forget").click(function(){
                      var successforget = document.getElementById('forgetpwdsuccessmsg');
                         successforget.style.display = "none"; 
                    $("#forgetfield").toggle("fadein");
                  });
                   $("#forgetcheckout").click(function(){
                      var successcheckforget = document.getElementById('forgetpwdchecksuccessmsg');
                         successcheckforget.style.display = "none"; 
                    $("#forgetcheckoutfield").toggle("fadein");
                        });
                });
                function forgetnow()
                {
                    var forgetname = document.getElementById("forgetemail").value;
                    var s="";
                    if(forgetname=="")
                    { 
                      s+="please enter your username<br /><br />";
                    }
                    if(s!="")
                    {
                         faliureforget();
                         var errorforget = document.getElementById('forgetpwderrormsg');
                         errorforget.style.display = "block"; 
                         errorforget.innerHTML = s;
                    }
                    else
                    {
                        successforget();
                         var errorpforget = document.getElementById('forgetpwderrormsg');
                         errorpforget.style.display = "none"; 
                         
                    }
                }
                 function successforget()
                               {
                                
                                   jQuery(function($) 
                                   {
                                    
                                        	var form = $('#forgetform');
                                            	form.submit(function(event){
                                        		event.preventDefault();
                                        		var form_status = $('<div class="span3"></div>');
                                                	$.ajax({
                                        			type: 'post',
                                        			url: $(this).attr('action'),
                                                    data: $('form').serialize()
                                                    }).done(function(data){
                                                        var erroruforget  = document.getElementById('forgetpwderrormsg');
                                                        var successforget = document.getElementById('forgetpwdsuccessmsg');
                                                        var fieldforget   = document.getElementById('forgetfield');
                                                        if(data.message == "username available")
                                                        {
                                                          fieldforget.style.display   = "none";
                                                          successforget.style.display = "block"; 
                                                          successforget.innerHTML      = "password sent successfully";
                                                        }
                                                        else if(data.message == "sorry invaild user")
                                                        {
                                                          erroruforget.style.display = "block"; 
                                                          erroruforget.innerHTML = "sorry your not vaild user";
                                                        }
                                                        else
                                                        {
                                                          erroruforget.style.display = "block"; 
                                                          erroruforget.innerHTML = "sorry your not vaild user";
                                                        }
                                        		
                                        		});
                                        	});
                                   });
                               }
                              
                            function faliureforget()
                            {
                                          jQuery(function($) 
                                                    {
                                                    	var form = $('#forgetform');
                                                    	form.submit(function(event)
                                                        {
                                                            event.preventDefault();
                                                        });
                                                    });
                            }